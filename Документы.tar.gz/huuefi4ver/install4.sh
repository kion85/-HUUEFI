#!/bin/bash

# ANSI escape codes for colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}🚀 HUUEFI Pro Max Ultra Installation${NC}"
echo -e "${BLUE}====================================${NC}"

# Create directories
HUUEFI_DIR="$HOME/.huuefi"
echo -e "${YELLOW}Creating necessary directories in ${HUUEFI_DIR}...${NC}"
mkdir -p "$HUUEFI_DIR"/{cache,modes,logs,temp,backups}
echo -e "${GREEN}✅ Directories created.${NC}"

# ==================== СОЗДАЕМ ОСНОВНОЙ ФАЙЛ ==================== #
echo -e "${YELLOW}📦 Creating HUUEFI Core System (huuefi-core.zsh)...${NC}"

cat > "$HUUEFI_DIR/huuefi-core.zsh" << 'EOF'
#!/bin/zsh
# HUUEFI CORE SYSTEM v3.0
# Multi-language execution environment

# ==================== CONFIGURATION ==================== #
HUUEFI_HOME="$HOME/.huuefi"
HUUEFI_CACHE_DIR="$HUUEFI_HOME/cache"
HUUEFI_MODES_DIR="$HUUEFI_HOME/modes"
HUUEFI_BACKUP_DIR="$HUUEFI_HOME/backups"
HUUEFI_LOG_FILE="$HUUEFI_HOME/huuefi.log"

# Load configuration
if [[ -f "$HUUEFI_HOME/huuefi.conf" ]]; then
    source "$HUUEFI_HOME/huuefi.conf"
fi

# Create directories if they don't exist (redundant but safe)
mkdir -p "$HUUEFI_HOME" "$HUUEFI_CACHE_DIR" "$HUUEFI_MODES_DIR" "$HUUEFI_BACKUP_DIR"

# Variables for UI/output, use defaults if not set by config
: ${HUUEFI_PROMPT_SYMBOL="🌀"}
: ${HUUEFI_ERROR_SYMBOL="❌"}
: ${HUUEFI_SUCCESS_SYMBOL="✅"}
: ${HUUEFI_LOG_LEVEL="INFO"}

# ==================== MODE DEFINITIONS ==================== #
declare -A HUUEFI_MODES=(
    ["light"]="🐧 Bash скрипты (LIGHT)"
    ["pro-cpp"]="🔧 C++ программы (PRO)"
    ["pro-asm"]="⚡ Pure Assembly (PRO)"
    ["pro-hybrid"]="🎯 C++ + inline ASM (PRO-HYBRID)"
    ["rust"]="🦀 Rust программы (RUST)"
    ["haskell"]="λ Haskell скрипты (HASKELL)"
    ["python"]="🐍 Python скрипты (PYTHON)"
    ["node"]="⬢ JavaScript/Node.js (NODE)"
    ["go"]="🐹 Go программы (GO)"
    ["ruby"]="💎 Ruby скрипты (RUBY)"
    ["lua"]="🌙 Lua скрипты (LUA)"
    ["huuefi-lang"]="🔥 HUUEFI собственный язык (HUUEFI-LANG)"
)

# ==================== CORE FUNCTIONS ==================== #
huuefi-log() {
    local level=${HUUEFI_LOG_LEVEL:-"INFO"}
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [$level] $1" >> "$HUUEFI_LOG_FILE"
}

huuefi-mode() {
    if [[ $# -lt 2 ]]; then
        echo -e "${HUUEFI_PROMPT_SYMBOL} Использование: huuefi-mode <файл.HUUEFI> <режим>"
        echo "   Доступные режимы: ${(k)HUUEFI_MODES[@]}"
        return 1
    fi
    
    local file="$1"
    local mode="$2"
    
    # Validation
    if [[ ! -f "$file" ]]; then
        echo -e "${HUUEFI_ERROR_SYMBOL} Файл '$file' не найден!"
        huuefi-log "ERROR: File not found - $file"
        return 1
    fi
    
    if [[ "$file" != *.HUUEFI ]]; then
        echo -e "${HUUEFI_ERROR_SYMBOL} Файл должен иметь расширение .HUUEFI!"
        huuefi-log "ERROR: Invalid extension - $file"
        return 1
    fi
    
    if [[ -z "${HUUEFI_MODES[$mode]}" ]]; then
        echo -e "${HUUEFI_ERROR_SYMBOL} Неизвестный режим: $mode"
        echo "   Доступные режимы: ${(k)HUUEFI_MODES[@]}"
        huuefi-log "ERROR: Unknown mode - $mode"
        return 1
    fi
    
    # Create backup if enabled
    if [[ "${HUUEFI_BACKUP_ENABLED:-true}" == "true" ]]; then
        local backup_file="$HUUEFI_BACKUP_DIR/$(basename "$file").mode_backup.$(date +%s)"
        cp "$file" "$backup_file"
        huuefi-log "Backup created: $backup_file"
    fi
    
    # Extract content (remove existing shebang or first line if it's a specific HUUEFI directive)
    local content=""
    local first_line=$(head -n 1 "$file")
    
    if [[ "$first_line" == "#!HUUEFI-PRO" || "$first_line" == "#!HUUEFI-LANG" || "$first_line" == "#!/bin/bash" || "$first_line" == "#!/usr/bin/env"* ]]; then
        content=$(tail -n +2 "$file")
    else
        content=$(cat "$file")
    fi
    
    # Apply new mode
    case "$mode" in
        light)
            echo "#!/bin/bash" > "$file"
            echo "$content" >> "$file"
            ;;
            
        pro-cpp)
            echo "#!HUUEFI-PRO" > "$file"
            if [[ -z "$content" ]]; then
                cat >> "$file" << 'EOL_CPP'
#include <iostream>
#include <vector>
#include <string>

using namespace std;

int main(int argc, char* argv[]) {
    cout << "🚀 HUUEFI C++ режим работает!" << endl;
    cout << "Аргументы: " << argc - 1 << endl;
    
    for (int i = 0; i < argc; i++) {
        cout << "  " << i << ": " << argv[i] << endl;
    }
    
    return 0;
}
EOL_CPP
            else
                echo "$content" >> "$file"
            fi
            ;;
            
        pro-asm)
            echo "#!HUUEFI-PRO" > "$file"
            if [[ -z "$content" ]]; then
                cat >> "$file" << 'EOL_ASM'
section .data
    msg db '🚀 HUUEFI Pure Assembly режим!', 0xA
    len equ $ - msg

section .text
    global _start

_start:
    ; Вывод сообщения
    mov rax, 1
    mov rdi, 1
    mov rsi, msg
    mov rdx, len
    syscall
    
    ; Завершение
    mov rax, 60
    xor rdi, rdi
    syscall
EOL_ASM
            else
                echo "$content" >> "$file"
            fi
            ;;
            
        pro-hybrid)
            echo "#!HUUEFI-PRO" > "$file"
            if [[ -z "$content" ]]; then
                cat >> "$file" << 'EOL_HYBRID'
#include <iostream>
using namespace std;

extern "C" void asm_function();

int main() {
    cout << "🎯 HUUEFI Hybrid режим (C++ + Assembly)!" << endl;
    
    // Inline Assembly
    asm("mov $1, %rax");
    asm("nop");
    
    asm_function();
    return 0;
}

// Assembly функции
asm(
".global asm_function\\n"
"asm_function:\\n"
"    mov $42, %rax\\n"
"    ret\\n"
);
EOL_HYBRID
            else
                echo "$content" >> "$file"
            fi
            ;;
            
        rust)
            echo "#!HUUEFI-PRO" > "$file"
            if [[ -z "$content" ]]; then
                cat >> "$file" << 'EOL_RUST'
fn main() {
    println!("🦀 HUUEFI Rust режим работает!");
    
    let args: Vec<String> = std::env::args().collect();
    println!("Аргументы: {:?}", args);
    
    let mut counter = 0;
    for i in 0..10 {
        counter += i;
    }
    println!("Результат: {}", counter);
}
EOL_RUST
            else
                echo "$content" >> "$file"
            fi
            ;;
            
        haskell)
            echo "#!HUUEFI-PRO" > "$file"
            if [[ -z "$content" ]]; then
                cat >> "$file" << 'EOL_HASKELL'
main :: IO ()
main = do
    putStrLn "λ HUUEFI Haskell режим работает!"
    
    args <- getArgs
    putStrLn $ "Аргументы: " ++ show args
    
    let result = sum [1..10]
    putStrLn $ "Сумма: " ++ show result
    
    let factorial n = product [1..n]
    putStrLn $ "Факториал 5: " ++ show (factorial 5)
EOL_HASKELL
            else
                echo "$content" >> "$file"
            fi
            ;;
            
        python)
            echo "#!/usr/bin/env python3" > "$file"
            if [[ -z "$content" ]]; then
                cat >> "$file" << 'EOL_PYTHON'
print("🐍 HUUEFI Python режим работает!")
import sys
print(f"Аргументы: {sys.argv}")

numbers = [1, 2, 3, 4, 5]
squares = [x**2 for x in numbers]
print(f"Квадраты: {squares}")

class HUUEFIProgram:
    def __init__(self, name):
        self.name = name
    
    def run(self):
        print(f"Запущена программа: {self.name}")

program = HUUEFIProgram("Python Demo")
program.run()
EOL_PYTHON
            else
                echo "$content" >> "$file"
            fi
            ;;
            
        node)
            echo "#!/usr/bin/env node" > "$file"
            if [[ -z "$content" ]]; then
                cat >> "$file" << 'EOL_NODE'
console.log("⬢ HUUEFI Node.js режим работает!");
console.log("Аргументы:", process.argv);

const fs = require('fs').promises;

async function demo() {
    try {
        const files = await fs.readdir('.');
        console.log("Файлы в папке:", files);
    } catch (error) {
        console.error("Ошибка:", error);
    }
}

demo();

const numbers = [1, 2, 3, 4, 5];
const doubled = numbers.map(x => x * 2);
console.log("Удвоенные числа:", doubled);
EOL_NODE
            else
                echo "$content" >> "$file"
            fi
            ;;
            
        go)
            echo "#!HUUEFI-PRO" > "$file"
            if [[ -z "$content" ]]; then
                cat >> "$file" << 'EOL_GO'
package main

import (
    "fmt"
    "os"
)

func main() {
    fmt.Println("🐹 HUUEFI Go режим работает!")
    fmt.Println("Аргументы:", os.Args)
    
    ch := make(chan int)
    
    go func() {
        sum := 0
        for i := 1; i <= 10; i++ {
            sum += i
        }
        ch <- sum
    }()
    
    result := <-ch
    fmt.Println("Сумма от 1 до 10:", result)
    
    p := Program{Name: "Go Demo"}
    p.Run()
}

type Program struct {
    Name string
}

func (p *Program) Run() {
    fmt.Printf("Запущена программа: %s\n", p.Name)
}
EOL_GO
            else
                echo "$content" >> "$file"
            fi
            ;;
            
        ruby)
            echo "#!/usr/bin/env ruby" > "$file"
            if [[ -z "$content" ]]; then
                cat >> "$file" << 'EOL_RUBY'
puts "💎 HUUEFI Ruby режим работает!"
puts "Аргументы: #{ARGV}"

numbers = [1, 2, 3, 4, 5]
squares = numbers.map { |x| x**2 }
puts "Квадраты: #{squares}"

class HUUEFIProgram
  attr_accessor :name
  
  def initialize(name)
    @name = name
  end
  
  def run
    puts "Запущена программа: #{@name}"
  end
end

program = HUUEFIProgram.new("Ruby Demo")
program.run

3.times do |i|
  puts "Итерация #{i + 1}"
end
EOL_RUBY
            else
                echo "$content" >> "$file"
            fi
            ;;
            
        lua)
            echo "#!/usr/bin/env lua" > "$file"
            if [[ -z "$content" ]]; then
                cat >> "$file" << 'EOL_LUA'
print("🌙 HUUEFI Lua режим работает!")
print("Аргументы:")
for i, v in ipairs(arg) do
    print("  " .. i .. ": " .. v)
end

local numbers = {1, 2, 3, 4, 5}
local squares = {}
for i, v in ipairs(numbers) do
    squares[i] = v * v
end

print("Квадраты:")
for i, v in ipairs(squares) do
    print("  " .. i .. ": " .. v)
end

local function greet(name)
    return "Привет, " .. name .. "!"
end

print(greet("Lua программист"))
EOL_LUA
            else
                echo "$content" >> "$file"
            fi
            ;;
            
        huuefi-lang)
            echo "#!HUUEFI-LANG" > "$file"
            if [[ -z "$content" ]]; then
                cat >> "$file" << 'EOL_HUUEFI_LANG'
// HUUEFI собственный язык программирования
// Синтаксис: C-подобный с русскими ключевыми словами

функция главная() {
    печать("🔥 HUUEFI собственный язык!");
    печать("Аргументы: ", аргументы);
    
    число x = 10;
    текст сообщение = "Привет мир!";
    логический флаг = истина;
    
    если (x > 5) {
        печать("x больше 5");
    } иначе {
        печать("x меньше или равно 5");
    }
    
    для (число i = 0; i < 5; i++) {
        печать("Итерация: ", i);
    }
    
    число результат = сумма(5, 3);
    печать("Сумма: ", результат);
    
    вернуть 0;
}

функция число сумма(число a, число b) {
    вернуть a + b;
}

главная();
EOL_HUUEFI_LANG
            else
                echo "$content" >> "$file"
            fi
            ;;
    esac
    
    echo -e "${HUUEFI_SUCCESS_SYMBOL} Файл '$file' переключен в режим: ${mode}"
    echo "📝 Описание: ${HUUEFI_MODES[$mode]}"
    huuefi-log "Mode changed: $file -> $mode"
}

huuefi-help-mode() {
    echo "🌈 HUUEFI РЕЖИМЫ ПРОГРАММИРОВАНИЯ:"
    echo "═╌┄┈┉┉┈┄╌═╌┄┈┉┉┈┄╌═╌┄┈┉┉┈┄╌═╌┄┈┉┉┈┄╌═╌┄┈┉┉┈┄╌═"
    
    for mode in "${(k)HUUEFI_MODES[@]}"; do
        printf "  %-15s - %s\n" "$mode" "${HUUEFI_MODES[$mode]}"
    done
    
    echo ""
    echo "🎯 КОМАНДЫ ДЛЯ ПЕРЕКЛЮЧЕНИЯ:"
    echo "  ${HUUEFI_PROMPT_SYMBOL} huuefi-mode file.HUUEFI light        → 🐧 Bash"
    echo "  ${HUUEFI_PROMPT_SYMBOL} huuefi-mode file.HUUEFI pro-cpp      → 🔧 C++"
    echo "  ${HUUEFI_PROMPT_SYMBOL} huuefi-mode file.HUUEFI rust         → 🦀 Rust"
    echo "  ${HUUEFI_PROMPT_SYMBOL} huuefi-mode file.HUUEFI haskell      → λ Haskell"
    echo "  ${HUUEFI_PROMPT_SYMBOL} huuefi-mode file.HUUEFI python       → 🐍 Python"
    echo "  ${HUUEFI_PROMPT_SYMBOL} huuefi-mode file.HUUEFI node         → ⬢ Node.js"
    echo "  ${HUUEFI_PROMPT_SYMBOL} huuefi-mode file.HUUEFI go           → 🐹 Go"
    echo "  ${HUUEFI_PROMPT_SYMBOL} huuefi-mode file.HUUEFI ruby         → 💎 Ruby"
    echo "  ${HUUEFI_PROMPT_SYMBOL} huuefi-mode file.HUUEFI lua          → 🌙 Lua"
    echo "  ${HUUEFI_PROMPT_SYMBOL} huuefi-mode file.HUUEFI huuefi-lang  → 🔥 HUUEFI Lang"
    echo ""
    echo "💡 СИНТАКСИС:"
    echo "  ${HUUEFI_PROMPT_SYMBOL} huuefi-mode <файл.HUUEFI> <режим>"
    echo "  ${HUUEFI_PROMPT_SYMBOL} huuefi-help-mode                   - эта справка"
}

huuefi-detect-mode() {
    if [[ $# -ne 1 ]]; then
        echo -e "${HUUEFI_PROMPT_SYMBOL} Использование: huuefi-detect-mode <файл.HUUEFI>"
        return 1
    fi
    
    local file="$1"
    
    if [[ ! -f "$file" ]]; then
        echo -e "${HUUEFI_ERROR_SYMBOL} Файл '$file' не найден!"
        return 1
    fi
    
    local first_line=$(head -n 1 "$file" 2>/dev/null)
    local content=$(cat "$file")
    
    echo "📊 Анализ файла: $(basename "$file")"
    echo "📝 Первая строка: '$first_line'"
    echo "📏 Размер: $(du -h "$file" | cut -f1)"
    echo "📄 Строк: $(wc -l < "$file")"
    echo ""
    echo "🔍 Определенный режим:"
    
    case "$first_line" in
        "#!/bin/bash")
            echo "🐧 LIGHT (Bash)"
            ;;
        "#!HUUEFI-PRO")
            if echo "$content" | grep -q "#include <iostream>"; then
                echo "🔧 PRO-CPP (C++)"
            elif echo "$content" | grep -q "fn main"; then
                echo "🦀 RUST"
            elif echo "$content" | grep -q "main :: IO ();"; then # Changed from 'main ::' because that's too broad
                echo "λ HASKELL"
            elif echo "$content" | grep -q "package main"; then
                echo "🐹 GO"
            elif echo "$content" | grep -q "section ."; then
                echo "⚡ PRO-ASM (Assembly)"
            elif echo "$content" | grep -q "asm("; then
                echo "🎯 PRO-HYBRID (C++ + ASM)"
            else
                echo "🔧 PRO (автоопределение)" # Fallback if specific Pro languages are not detected
            fi
            ;;
        "#!/usr/bin/env python"*)
            echo "🐍 PYTHON"
            ;;
        "#!/usr/bin/env node")
            echo "⬢ NODE.JS"
            ;;
        "#!/usr/bin/env ruby")
            echo "💎 RUBY"
            ;;
        "#!/usr/bin/env lua")
            echo "🌙 LUA"
            ;;
        "#!HUUEFI-LANG")
            echo "🔥 HUUEFI LANG"
            ;;
        *)
            echo "❓ НЕИЗВЕСТНЫЙ РЕЖИМ"
            ;;
    esac
}

# ==================== ALIASES ==================== #
# We add a space after the function name to allow Zsh completion to work for arguments
alias .mode='huuefi-mode '
alias .help-mode='huuefi-help-mode '
alias .detect-mode='huuefi-detect-mode '

# Quick mode switching aliases
# These aliases require a file argument, e.g., '.light myprogram.HUUEFI'
alias .light='huuefi-mode ' light
alias .cpp='huuefi-mode ' pro-cpp
alias .asm='huuefi-mode ' pro-asm
alias .hybrid='huuefi-mode ' pro-hybrid
alias .rust='huuefi-mode ' rust
alias .haskell='huuefi-mode ' haskell
alias .python='huuefi-mode ' python
alias .node='huuefi-mode ' node
alias .go='huuefi-mode ' go
alias .ruby='huuefi-mode ' ruby
alias .lua='huuefi-mode ' lua
alias .huuefi-lang='huuefi-mode ' huuefi-lang

# ==================== INITIALIZATION ==================== #

# Check if HUUEFI_SHOW_BANNER is true (default to true if not set)
if [[ "${HUUEFI_SHOW_BANNER:-true}" == "true" ]]; then
    # Simple banner, can be made more elaborate using config settings
    echo ""
    echo "██╗  ██╗██╗   ██╗██╗   ██╗███████╗███████╗  ${HUUEFI_PROMPT_SYMBOL}"
    echo "██║  ██║██║   ██║██║   ██║██╔════╝██╔════╝"
    echo "███████║██║   ██║██║   ██║█████╗  ███████╗  ${HUUEFI_PROMPT_SYMBOL} HUUEFI System Loaded"
    echo "██╔══██║██║   ██║██║   ██║██╔══╝  ╚════██║"
    echo "██║  ██║╚██████╔╝╚██████╔╝███████╗███████║"
    echo "╚═╝  ╚═╝ ╚═════╝  ╚═════╝ ╚══════╝╚══════╝"
    echo ""
fi

echo -e "${HUUEFI_PROMPT_SYMBOL} HUUEFI Multi-Language System loaded!"
echo "💡 Доступно ${#HUUEFI_MODES[@]} режимов программирования!"
echo "   Для справки: huuefi-help-mode"
huuefi-log "HUUEFI system initialized"

# ==================== AUTOLOAD FUNCTIONS (EXAMPLE) ==================== #
# If you want to auto-load specific modules or run checks on startup,
# you can add them here. For example, checking for old backups:
# huuefi-cleanup-backups # (Add this function if you implement cleanup logic)
EOF
echo -e "${GREEN}✅ HUUEFI Core System created.${NC}"

# ==================== СОЗДАЕМ КОНФИГ ФАЙЛ huuefi.conf ==================== #
echo -e "${YELLOW}📦 Creating huuefi.conf configuration...${NC}"

cat > "$HUUEFI_DIR/huuefi.conf" << 'EOF'
# HUUEFI Configuration File
# Version: 3.0

# Path settings
export HUUEFI_HOME="$HOME/.huuefi"
export HUUEFI_CACHE_DIR="$HUUEFI_HOME/cache"
export HUUEFI_BACKUP_DIR="$HUUEFI_HOME/backups"
export HUUEFI_MODES_DIR="$HUUEFI_HOME/modes"
export HUUEFI_LOG_FILE="$HUUEFI_HOME/huuefi.log"

# Execution settings
export HUUEFI_AUTO_COMPILE="true" # Set to "true" or "false"
export HUUEFI_KEEP_BACKUPS="5"   # Number of backups to retain
export HUUEFI_LOG_LEVEL="INFO"   # INFO, DEBUG, WARNING, ERROR
export HUUEFI_MAX_BACKUP_AGE="30d" # Max age for backups (e.g., 7d, 30d, 1y)

# Compiler settings
export HUUEFI_CPP_COMPILER="g++"
export HUUEFI_CPP_FLAGS="-std=c++17 -O2 -Wall"
export HUUEFI_RUST_COMPILER="rustc"
export HUUEFI_RUST_FLAGS="-O"
export HUUEFI_GO_COMPILER="go build -o" # For building executables go build -o <output_name> <source.go>
export HUUEFI_ASM_COMPILER="nasm"
export HUUEFI_ASM_FLAGS="-f elf64" # For 64-bit ELF format
export HUUEFI_HASKELL_COMPILER="ghc"
export HUUEFI_HASKELL_FLAGS="-O"

# UI settings
export HUUEFI_SHOW_BANNER="true"
export HUUEFI_COLORS="true" # Not fully implemented in core yet, but good for future
export HUUEFI_ANIMATIONS="false" # Placeholder for future
export HUUEFI_PROMPT_SYMBOL="🌀"
export HUUEFI_ERROR_SYMBOL="❌"
export HUUEFI_SUCCESS_SYMBOL="✅"

# Performance settings
export HUUEFI_CACHE_ENABLED="true"
export HUUEFI_CACHE_TTL="3600" # Time-to-live for cache entries in seconds
export HUUEFI_PARALLEL_COMPILE="false" # Enable parallel compilation for supported languages/modes
export HUUEFI_MAX_THREADS="4" # Max threads for parallel compilation

# Security settings
export HUUEFI_VALIDATE_INPUT="true" # Perform input validation
export HUUEFI_SANDBOX_MODE="false" # Restrict execution environment (advanced, requires external tools like firejail)
export HUUEFI_MAX_FILE_SIZE="10M" # Max size for .HUUEFI files (e.g., 10M, 1G)

# Language specific settings (interpreters)
export HUUEFI_PYTHON_INTERPRETER="python3"
export HUUEFI_NODE_INTERPRETER="node"
export HUUEFI_RUBY_INTERPRETER="ruby"
export HUUEFI_LUA_INTERPRETER="lua"

# Theme settings (placeholder for future UI features)
export HUUEFI_THEME="default"
export HUUEFI_COLOR_PRIMARY="blue"
export HUUEFI_COLOR_SECONDARY="green"
export HUUEFI_COLOR_ERROR="red"
export HUUEFI_COLOR_WARNING="yellow"

# Debug settings
export HUUEFI_DEBUG="false" # Enable verbose debug logging
export HUUEFI_VERBOSE="false" # More verbose output in console
export HUUEFI_TRACE="false" # Trace shell execution (very verbose!)

# Auto-cleanup settings
export HUUEFI_AUTO_CLEANUP="true" # Enable automatic cleanup of old cache/backups
export HUUEFI_CLEANUP_INTERVAL="7d" # How often cleanup runs (e.g., 1d, 7d, 30d)
export HUUEFI_MAX_LOG_SIZE="10M" # Max size for log file before rotation/truncation

# Notification settings
export HUUEFI_NOTIFICATIONS="true" # Enable desktop notifications
export HUUEFI_NOTIFY_ON_SUCCESS="true"
export HUUEFI_NOTIFY_ON_ERROR="true"

# Update settings
export HUUEFI_AUTO_UPDATE="false" # Enable automatic update checks
export HUUEFI_UPDATE_CHECK_INTERVAL="30d" # How often to check for updates

# Backup settings
export HUUEFI_BACKUP_ENABLED="true" # Overall backup feature toggle
export HUUEFI_BACKUP_COUNT="10" # Number of backups to keep for each file
export HUUEFI_BACKUP_COMPRESSION="true" # Compress backups (requires gzip/zstd)

# Network settings (if future features require external access)
export HUUEFI_NETWORK_TIMEOUT="30" # Timeout for network operations in seconds
export HUUEFI_DOWNLOAD_RETRIES="3" # Number of retries for downloads

# User customization area - add your custom settings below
# export MY_CUSTOM_SETTING="value"

# Load user custom config if exists (this file should be created manually by user)
if [[ -f "$HUUEFI_HOME/user-config.zsh" ]]; then
    source "$HUUEFI_HOME/user-config.zsh"
fi
EOF
echo -e "${GREEN}✅ huuefi.conf created.${NC}"

# ==================== СОЗДАЕМ РЕЖИМЫ ==================== #
echo -e "${YELLOW}📦 Creating mode templates...${NC}"

# C++ Mode
cat > "$HUUEFI_DIR/modes/cpp.hmode" << 'EOF_CPP_MODE'
#include <iostream>
#include <vector>
#include <string>

using namespace std;

int main(int argc, char* argv[]) {
    cout << "🚀 HUUEFI C++ режим работает!" << endl;
    cout << "Аргументы: " << argc - 1 << endl;
    
    for (int i = 0; i < argc; i++) {
        cout << "  " << i << ": " << argv[i] << endl;
    }
    
    return 0;
}
EOF_CPP_MODE

# Python Mode
cat > "$HUUEFI_DIR/modes/python.hmode" << 'EOF_PYTHON_MODE'
print("🐍 HUUEFI Python режим работает!")
import sys
print(f"Аргументы: {sys.argv}")

numbers = [1, 2, 3, 4, 5]
squares = [x**2 for x in numbers]
print(f"Квадраты: {squares}")

class HUUEFIProgram:
    def __init__(self, name):
        self.name = name
    
    def run(self):
        print(f"Запущена программа: {self.name}")

program = HUUEFIProgram("Python Demo")
program.run()
EOF_PYTHON_MODE

# Rust Mode
cat > "$HUUEFI_DIR/modes/rust.hmode" << 'EOF_RUST_MODE'
fn main() {
    println!("🦀 HUUEFI Rust режим работает!");
    
    let args: Vec<String> = std::env::args().collect();
    println!("Аргументы: {:?}", args);
    
    let mut counter = 0;
    for i in 0..10 {
        counter += i;
    }
    println!("Результат: {}", counter);
}
EOF_RUST_MODE

# Add other modes similarly if you wish to pre-populate them as separate files.
# The huuefi-core.zsh script already contains the default content for each mode,
# so these .hmode files are primarily for user reference or if you want to allow
# users to easily edit/create new default templates.
echo -e "${GREEN}✅ Created mode templates.${NC}"


# ==================== УСТАНАВЛИВАЕМ ЗАВИСИМОСТИ ==================== #
echo -e "${YELLOW}📦 Installing dependencies... (This may require sudo password)${NC}"

# Define the packages based on modes
PACKAGES="g++ nasm rustc ghc python3 nodejs golang ruby lua5.3"

# Check if apt is available
if command -v apt &> /dev/null; then
    echo -e "${BLUE}Updating apt package list...${NC}"
    sudo apt update
    if [ $? -ne 0 ]; then
        echo -e "${RED}❌ Failed to update apt. Please check your internet connection or apt sources.${NC}"
        # Continue installation as non-critical
    fi
    echo -e "${BLUE}Installing required packages: ${PACKAGES}...${NC}"
    sudo apt install -y $PACKAGES
    if [ $? -ne 0 ]; then
        echo -e "${RED}❌ Failed to install all dependencies. Some features might not work.${NC}"
    else
        echo -e "${GREEN}✅ Dependencies installed successfully.${NC}"
    fi
# Check if dnf is available (for Fedora/RHEL derivatives)
elif command -v dnf &> /dev/null; then
    echo -e "${BLUE}Updating dnf package list...${NC}"
    sudo dnf check-update
    if [ $? -ne 0 ]; then
        echo -e "${RED}❌ Failed to update dnf. Please check your internet connection or dnf sources.${NC}"
    fi
    echo -e "${BLUE}Installing required packages: ${PACKAGES}...${NC}"
    # Adjust package names for dnf if necessary (e.g., nodejs might be node)
    sudo dnf install -y gcc-c++ nasm rust ghc python3 nodejs golang ruby lua
    if [ $? -ne 0 ]; then
        echo -e "${RED}❌ Failed to install all dependencies. Some features might not work.${NC}"
    else
        echo -e "${GREEN}✅ Dependencies installed successfully.${NC}"
    fi
# Check if pacman is available (for Arch Linux)
elif command -v pacman &> /dev/null; then
    echo -e "${BLUE}Updating pacman package list...${NC}"
    sudo pacman -Sy
    if [ $? -ne 0 ]; then
        echo -e "${RED}❌ Failed to update pacman. Please check your internet connection or pacman sources.${NC}"
    fi
    echo -e "${BLUE}Installing required packages: ${PACKAGES}...${NC}"
    # Adjust package names for pacman if necessary (e.g., nodejs might be nodejs, golang might be go)
    sudo pacman -S --noconfirm gcc nasm rust ghc python nodejs go ruby lua
    if [ $? -ne 0 ]; then
        echo -e "${RED}❌ Failed to install all dependencies. Some features might not work.${NC}"
    else
        echo -e "${GREEN}✅ Dependencies installed successfully.${NC}"
    fi
else
    echo -e "${YELLOW}⚠️  No supported package manager (apt, dnf, pacman) found. Please install dependencies manually:${NC}"
    echo "   Required: g++, nasm, rustc, ghc, python3, nodejs, golang, ruby, lua5.3"
fi


# ==================== НАСТРАИВАЕМ ПРАВА ==================== #
echo -e "${YELLOW}Configuring file permissions...${NC}"
chmod +x "$HUUEFI_DIR/huuefi-core.zsh"
chmod 755 "$HUUEFI_DIR"
echo -e "${GREEN}✅ Permissions set.${NC}"

# ==================== ДОБАВЛЯЕМ В .ZSHRC ==================== #
echo -e "${YELLOW}Integrating HUUEFI into your ~/.zshrc...${NC}"
if ! grep -q "source '$HUUEFI_DIR/huuefi-core.zsh'" ~/.zshrc; then
    echo "" >> ~/.zshrc
    echo "# HUUEFI Extension" >> ~/.zshrc
    echo "source '$HUUEFI_DIR/huuefi-core.zsh'" >> ~/.zshrc
    echo -e "${GREEN}✅ Added HUUEFI source to ~/.zshrc. It will load after your existing configs.${NC}"
else
    echo -e "${YELLOW}⚠️  HUUEFI is already sourced in ~/.zshrc. Skipping modification.${NC}"
fi

echo ""
echo -e "${GREEN}🎉 HUUEFI Pro Max Ultra installation complete!${NC}"
echo -e "${BLUE}💻 Please restart your terminal or run: ${YELLOW}source ~/.zshrc${NC} to load HUUEFI.${NC}"
echo -e "${BLUE}📋 Configuration file: ${YELLOW}$HUUEFI_DIR/huuefi.conf${NC}"
echo -e "${BLUE}📖 Explore modes: ${YELLOW}.help-mode${NC} or ${YELLOW}huuefi-help-mode${NC}"