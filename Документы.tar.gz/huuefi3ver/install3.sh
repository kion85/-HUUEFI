#!/bin/bash

# ============================================================================
# HUUEFI Pro Max Ultra Installation Script
# This script installs the HUUEFI multi-language execution environment.
# v3.1 - Refactored config management
# ============================================================================

echo "🚀 HUUEFI Pro Max Ultra Installation"
echo "===================================="

# --- Configuration ---
HUUEFI_DIR="$HOME/.huuefi"
ZSHRC_FILE="$HOME/.zshrc"

# --- Create directories ---
echo "📂 Creating necessary directories..."
mkdir -p "$HUUEFI_DIR"/{cache,modes,logs,temp,backups}
echo "✅ Directories created: $HUUEFI_DIR"

# ==================== CREATE HUUEFI CORE SYSTEM FILE ==================== #
echo "📦 Creating HUUEFI Core System Script (huuefi-core.zsh)..."

cat > "$HUUEFI_DIR/huuefi-core.zsh" << 'EOF'
#!/bin/zsh
# HUUEFI CORE SYSTEM v3.1
# Multi-language execution environment

# ==================== CONFIGURATION LOADING ==================== #
# Define the base directory for HUUEFI
export HUUEFI_HOME="$HOME/.huuefi"

# Load the main configuration file
HUUEFI_CONFIG_FILE="$HUUEFI_HOME/huuefi.conf"
if [[ -f "$HUUEFI_CONFIG_FILE" ]]; then
    # Source the config file to load all HUUEFI related variables
    source "$HUUEFI_CONFIG_FILE"
    # Fallback to default values if not set in config
    : ${HUUEFI_CACHE_DIR:="$HUUEFI_HOME/cache"}
    : ${HUUEFI_MODES_DIR:="$HUUEFI_HOME/modes"}
    : ${HUUEFI_BACKUP_DIR:="$HUUEFI_HOME/backups"}
    : ${HUUEFI_LOG_FILE:="$HUUEFI_HOME/huuefi.log"}
    : ${HUUEFI_SHOW_BANNER:=true}
    : ${HUUEFI_PROMPT_SYMBOL:="🌀"}
    : ${HUUEFI_SUCCESS_SYMBOL:="✅"}
    : ${HUUEFI_ERROR_SYMBOL:="❌"}
else
    echo "⚠️ HUUEFI configuration file not found: $HUUEFI_CONFIG_FILE. Using default values." >&2
    # Define default paths if config is missing
    export HUUEFI_CACHE_DIR="$HUUEFI_HOME/cache"
    export HUUEFI_MODES_DIR="$HUUEFI_HOME/modes"
    export HUUEFI_BACKUP_DIR="$HUUEFI_HOME/backups"
    export HUUEFI_LOG_FILE="$HUUEFI_HOME/huuefi.log"
    export HUUEFI_SHOW_BANNER=true
    export HUUEFI_PROMPT_SYMBOL="🌀"
    export HUUEFI_SUCCESS_SYMBOL="✅"
    export HUUEFI_ERROR_SYMBOL="❌"
fi

# Ensure directories exist (redundant but safe after config load)
mkdir -p "$HUUEFI_HOME" "$HUUEFI_CACHE_DIR" "$HUUEFI_MODES_DIR" "$HUUEFI_BACKUP_DIR"

# ==================== MODE DEFINITIONS ==================== #
declare -A HUUEFI_MODES=(
    ["light"]="🐧 Bash скрипты (LIGHT)"
    ["pro-cpp"]="🔧 C++ программы (PRO)"
    ["pro-asm"]="⚡ Pure Assembly (PRO)"
    ["pro-hybrid"]="🎯 C++ + inline ASM (PRO-HYBRID)"
    ["rust"]="🦀 Rust программы (RUST)"
    ["haskell"]="λ Haskell скрипты (HASKELL)"
    ["python"]="🐍 Python скрипты (PYTHON)"
    ["node"]="⬢ JavaScript/Node.js (NODE)"
    ["go"]="🐹 Go программы (GO)"
    ["ruby"]="💎 Ruby скрипты (RUBY)"
    ["lua"]="🌙 Lua скрипты (LUA)"
    ["huuefi-lang"]="🔥 HUUEFI собственный язык (HUUEFI-LANG)"
)

# ==================== CORE FUNCTIONS ==================== #
huuefi-log() {
    echo "[$HUUEFI_PROMPT_SYMBOL $(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$HUUEFI_LOG_FILE"
}

huuefi-mode() {
    if [[ $# -lt 2 ]]; then
        echo "$HUUEFI_PROMPT_SYMBOL Использование: huuefi-mode <файл.HUUEFI> <режим>"
        echo "   Доступные режимы: ${(k)HUUEFI_MODES[@]}"
        return 1
    fi
    
    local file="$1"
    local mode="$2"
    
    # Validation
    if [[ ! -f "$file" ]]; then
        echo "$HUUEFI_ERROR_SYMBOL Файл '$file' не найден!"
        huuefi-log "ERROR: File not found - $file"
        return 1
    fi
    
    if [[ "$file" != *.HUUEFI ]]; then
        echo "$HUUEFI_ERROR_SYMBOL Файл должен иметь расширение .HUUEFI!"
        huuefi-log "ERROR: Invalid extension - $file"
        return 1
    fi
    
    if [[ -z "${HUUEFI_MODES[$mode]}" ]]; then
        echo "$HUUEFI_ERROR_SYMBOL Неизвестный режим: $mode"
        echo "   Доступные режимы: ${(k)HUUEFI_MODES[@]}"
        huuefi-log "ERROR: Unknown mode - $mode"
        return 1
    fi
    
    # Create backup
    # Check if backups are enabled and count is greater than 0
    if [[ "$HUUEFI_BACKUP_ENABLED" = true && "$HUUEFI_BACKUP_COUNT" -gt 0 ]]; then
        local backup_file="$HUUEFI_BACKUP_DIR/$(basename "$file").backup.$(date +%s)"
        cp "$file" "$backup_file"
        huuefi-log "Backup created: $backup_file"
        
        # Implement backup rotation/cleanup
        local backup_files_sorted=( $(ls -t "$HUUEFI_BACKUP_DIR"/$(basename "$file").backup.* 2>/dev/null) )
        if (( ${#backup_files_sorted[@]} > HUUEFI_BACKUP_COUNT )); then
            for (( i=HUUEFI_BACKUP_COUNT; i<${#backup_files_sorted[@]}; i++ )); do
                rm "${backup_files_sorted[i]}"
                huuefi-log "Removed old backup: ${backup_files_sorted[i]}"
            done
        fi
    fi
    
    # Extract content (remove existing shebang)
    local content=""
    local first_line=$(head -n 1 "$file")
    
    if [[ "$first_line" == "#!HUUEFI-PRO" || "$first_line" == "#!HUUEFI-LANG" || "$first_line" == "#!/bin/bash" || "$first_line" == "#!/usr/bin/env"* ]]; then
        content=$(tail -n +2 "$file")
    else
        content=$(cat "$file")
    fi
    
    # Apply new mode
    case "$mode" in
        light)
            echo "#!/bin/bash" > "$file"
            echo "$content" >> "$file"
            ;;
            
        pro-cpp)
            # Use 'g++' from config, with 'HUUEFI_CPP_FLAGS'
            if [[ -z "$content" ]]; then
                cat "$HUUEFI_MODES_DIR/cpp.hmode" > "$file"
            else
                echo "#!HUUEFI-PRO" > "$file"
                echo "$content" >> "$file"
            fi
            ;;
            
        pro-asm)
            # Use 'nasm' from config, with 'HUUEFI_ASM_FLAGS'
            if [[ -z "$content" ]]; then
                cat "$HUUEFI_MODES_DIR/asm.hmode" > "$file"
            else
                echo "#!HUUEFI-PRO" > "$file"
                echo "$content" >> "$file"
            fi
            ;;
            
        pro-hybrid)
            if [[ -z "$content" ]]; then
                cat "$HUUEFI_MODES_DIR/hybrid.hmode" > "$file"
            else
                echo "#!HUUEFI-PRO" > "$file"
                echo "$content" >> "$file"
            fi
            ;;
            
        rust)
            # Use 'rustc' from config, with 'HUUEFI_RUST_FLAGS'
            if [[ -z "$content" ]]; then
                cat "$HUUEFI_MODES_DIR/rust.hmode" > "$file"
            else
                echo "#!HUUEFI-PRO" > "$file"
                echo "$content" >> "$file"
            fi
            ;;
            
        haskell)
            if [[ -z "$content" ]]; then
                cat "$HUUEFI_MODES_DIR/haskell.hmode" > "$file"
            else
                echo "#!HUUEFI-PRO" > "$file"
                echo "$content" >> "$file"
            fi
            ;;
            
        python)
            # Use 'HUUEFI_PYTHON_INTERPRETER' from config
            if [[ -z "$content" ]]; then
                echo "#!/usr/bin/env $HUUEFI_PYTHON_INTERPRETER" > "$file"
                cat "$HUUEFI_MODES_DIR/python.hmode" >> "$file"
            else
                echo "#!/usr/bin/env $HUUEFI_PYTHON_INTERPRETER" > "$file"
                echo "$content" >> "$file"
            fi
            ;;
            
        node)
            # Use 'HUUEFI_NODE_INTERPRETER' from config
            if [[ -z "$content" ]]; then
                echo "#!/usr/bin/env $HUUEFI_NODE_INTERPRETER" > "$file"
                cat "$HUUEFI_MODES_DIR/node.hmode" >> "$file"
            else
                echo "#!/usr/bin/env $HUUEFI_NODE_INTERPRETER" > "$file"
                echo "$content" >> "$file"
            fi
            ;;
            
        go)
            # Use 'go build' from config
            if [[ -z "$content" ]]; then
                cat "$HUUEFI_MODES_DIR/go.hmode" > "$file"
            else
                echo "#!HUUEFI-PRO" > "$file"
                echo "$content" >> "$file"
            fi
            ;;
            
        ruby)
            # Use 'HUUEFI_RUBY_INTERPRETER' from config
            if [[ -z "$content" ]]; then
                echo "#!/usr/bin/env $HUUEFI_RUBY_INTERPRETER" > "$file"
                cat "$HUUEFI_MODES_DIR/ruby.hmode" >> "$file"
            else
                echo "#!/usr/bin/env $HUUEFI_RUBY_INTERPRETER" > "$file"
                echo "$content" >> "$file"
            fi
            ;;
            
        lua)
            # Use 'HUUEFI_LUA_INTERPRETER' from config
            if [[ -z "$content" ]]; then
                echo "#!/usr/bin/env $HUUEFI_LUA_INTERPRETER" > "$file"
                cat "$HUUEFI_MODES_DIR/lua.hmode" >> "$file"
            else
                echo "#!/usr/bin/env $HUUEFI_LUA_INTERPRETER" > "$file"
                echo "$content" >> "$file"
            fi
            ;;
            
        huuefi-lang)
            if [[ -z "$content" ]]; then
                cat "$HUUEFI_MODES_DIR/huuefi-lang.hmode" > "$file"
            else
                echo "#!HUUEFI-LANG" > "$file"
                echo "$content" >> "$file"
            fi
            ;;
    esac
    
    echo "$HUUEFI_SUCCESS_SYMBOL Файл '$file' переключен в режим: $mode"
    echo "📝 Описание: ${HUUEFI_MODES[$mode]}"
    huuefi-log "Mode changed: $file -> $mode"
}

huuefi-help-mode() {
    echo "🌈 HUUEFI РЕЖИМЫ ПРОГРАММИРОВАНИЯ:"
    echo "═╌┄┈┉┉┈┄╌═╌┄┈┉┉┈┄╌═╌┄┈┉┉┈┄╌═╌┄┈┉┉┈┄╌═╌┄┈┉┉┈┄╌═"
    
    for mode in "${(k)HUUEFI_MODES[@]}"; do
        printf "  %-15s - %s\n" "$mode" "${HUUEFI_MODES[$mode]}"
    done
    
    echo ""
    echo "🎯 КОМАНДЫ ДЛЯ ПЕРЕКЛЮЧЕНИЯ:"
    echo "  huuefi-mode file.HUUEFI light        → 🐧 Bash"
    echo "  huuefi-mode file.HUUEFI pro-cpp      → 🔧 C++"
    echo "  huuefi-mode file.HUUEFI rust         → 🦀 Rust"
    echo "  huuefi-mode file.HUUEFI haskell      → λ Haskell"
    echo "  huuefi-mode file.HUUEFI python       → 🐍 Python"
    echo "  huuefi-mode file.HUUEFI node         → ⬢ Node.js"
    echo "  huuefi-mode file.HUUEFI go           → 🐹 Go"
    echo "  huuefi-mode file.HUUEFI ruby         → 💎 Ruby"
    echo "  huuefi-mode file.HUUEFI lua          → 🌙 Lua"
    echo "  huuefi-mode file.HUUEFI huuefi-lang  → 🔥 HUUEFI Lang"
    echo ""
    echo "💡 СИНТАКСИС:"
    echo "  huuefi-mode <файл.HUUEFI> <режим>"
    echo "  huuefi-help-mode                   - эта справка"
}

huuefi-detect-mode() {
    if [[ $# -ne 1 ]]; then
        echo "$HUUEFI_PROMPT_SYMBOL Использование: huuefi-detect-mode <файл.HUUEFI>"
        return 1
    fi
    
    local file="$1"
    
    if [[ ! -f "$file" ]]; then
        echo "$HUUEFI_ERROR_SYMBOL Файл '$file' не найден!"
        return 1
    fi
    
    local first_line=$(head -n 1 "$file" 2>/dev/null)
    local content=$(cat "$file")
    
    echo "📊 Анализ файла: $(basename "$file")"
    echo "📝 Первая строка: '$first_line'"
    echo "📏 Размер: $(du -h "$file" | cut -f1)"
    echo "📄 Строк: $(wc -l < "$file")"
    echo ""
    echo "🔍 Определенный режим:"
    
    case "$first_line" in
        "#!/bin/bash")
            echo "🐧 LIGHT (Bash)"
            ;;
        "#!HUUEFI-PRO")
            if echo "$content" | grep -q "#include"; then
                echo "🔧 PRO-CPP (C++)"
            elif echo "$content" | grep -q "fn main"; then
                echo "🦀 RUST"
            elif echo "$content" | grep -q "main ::"; then
                echo "λ HASKELL"
            elif echo "$content" | grep -q "package main"; then
                echo "🐹 GO"
            elif echo "$content" | grep -q "section ."; then
                echo "⚡ PRO-ASM (Assembly)"
            elif echo "$content" | grep -q "asm("; then
                echo "🎯 PRO-HYBRID (C++ + ASM)"
            else
                echo "🔧 PRO (автоопределение)"
            fi
            ;;
        "#!/usr/bin/env $HUUEFI_PYTHON_INTERPRETER"*)
            echo "🐍 PYTHON"
            ;;
        "#!/usr/bin/env $HUUEFI_NODE_INTERPRETER")
            echo "⬢ NODE.JS"
            ;;
        "#!/usr/bin/env $HUUEFI_RUBY_INTERPRETER")
            echo "💎 RUBY"
            ;;
        "#!/usr/bin/env $HUUEFI_LUA_INTERPRETER")
            echo "🌙 LUA"
            ;;
        "#!HUUEFI-LANG")
            echo "🔥 HUUEFI LANG"
            ;;
        *)
            echo "❓ НЕИЗВЕСТНЫЙ РЕЖИМ"
            ;;
    esac
}

# ==================== ALIASES AND FUNCTIONS FOR QUICK USAGE ==================== #
# These aliases simplify calling HUUEFI functions.
# Ensure functions are defined before aliases
alias .mode='huuefi-mode '
alias .help-mode='huuefi-help-mode '
alias .detect-mode='huuefi-detect-mode '

# Quick mode switching aliases for convenience
# Note: These aliases directly supply the mode name, so they don't break if
# HUUEFI_MODES is modified, but the full huuefi-mode function would need the file.
alias .light='huuefi-mode ' light
alias .cpp='huuefi-mode ' pro-cpp
alias .asm='huuefi-mode ' pro-asm
alias .hybrid='huuefi-mode ' pro-hybrid
alias .rust='huuefi-mode ' rust
alias .haskell='huuefi-mode ' haskell
alias .python='huuefi-mode ' python
alias .node='huuefi-mode ' node
alias .go='huuefi-mode ' go
alias .ruby='huuefi-mode ' ruby
alias .lua='huuefi-mode ' lua
alias .huuefi-lang='huuefi-mode ' huuefi-lang


# ==================== INITIALIZATION MESSAGE ==================== #
if [[ "$HUUEFI_SHOW_BANNER" = true ]]; then
    # Enhanced banner (optional graphical element)
    echo ""
    echo "      ▄▄▀▀▀▄▄"
    echo "     ▀▀▀▀▀▀▀▀▀▀▄"
    echo "   ▄▀▀▀▀▀▀▄▀▀▀▀▀▀▄   ▄▄"
    echo " ▄▀▀▀▀▀▀▀▀▀▄  ▀▀▀▀▀▀▀▀▀         $HUUEFI_PROMPT_SYMBOL HUUEFI Multi-Language System loaded!"
    echo " ▀▀▀▀▀▀▀▀▀▀▀▄    ▀▀▀▀           💡 Available ${#HUUEFI_MODES[@]} programming modes!"
    echo "▄▄▄▀▀▀▀▀▀▀▀▀▀▀▀▄▄▄▀▀▀           👉 For help, type: huuefi-help-mode"
    echo "▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▄          "
    echo "▀▀▀▀▀▀ ▄▀▀▀▀▀▀▀▀▀▀▀▀ ▄▄▄▄▄▀▀    $HUUEFI_PROMPT_SYMBOL Configuration file: $HUUEFI_CONFIG_FILE"
    echo "       ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀  "
    echo "       ▀▀▀▀ ▀▀▀▀▀▀▀▀▀▀▀       "
    echo "               ▀▀▀▀▀           "
    echo ""
else
    echo "$HUUEFI_PROMPT_SYMBOL HUUEFI Multi-Language System loaded!"
    echo "💡 Available ${#HUUEFI_MODES[@]} programming modes!"
    echo "   For help, type: huuefi-help-mode"
fi
huuefi-log "HUUEFI system initialized"
EOF
echo "✅ huuefi-core.zsh created."

# ==================== CREATE HUUEFI CONFIGURATION FILE ==================== #
echo "📦 Creating huuefi.conf (main configuration file)..."

cat > "$HUUEFI_DIR/huuefi.conf" << 'EOF'
# ============================================================================
# HUUEFI Configuration File
# Version: 3.1
#
# This file stores all configurable settings for the HUUEFI system.
# It is sourced by huuefi-core.zsh upon terminal startup.
# ============================================================================

# --- Path settings ---
export HUUEFI_HOME="$HOME/.huuefi"
export HUUEFI_CACHE_DIR="$HUUEFI_HOME/cache"
export HUUEFI_MODES_DIR="$HUUEFI_HOME/modes"
export HUUEFI_BACKUP_DIR="$HUUEFI_HOME/backups"
export HUUEFI_LOG_FILE="$HUUEFI_HOME/huuefi.log"
export HUUEFI_TEMP_DIR="$HUUEFI_HOME/temp" # Not explicitly used yet, but good to have

# --- Execution settings ---
export HUUEFI_AUTO_COMPILE=true     # Automatically compile PRO modes
export HUUEFI_KEEP_BACKUPS=5        # Number of backups to keep per file
export HUUEFI_LOG_LEVEL="INFO"      # Logging level: DEBUG, INFO, WARNING, ERROR, CRITICAL
export HUUEFI_MAX_BACKUP_AGE="30d"  # Max age for backups (e.g., 7d, 30d, 1y)

# --- Compiler settings ---
# Define specific commands and flags for different languages/compilers
export HUUEFI_CPP_COMPILER="g++"
export HUUEFI_CPP_FLAGS="-std=c++17 -O2 -Wall"
export HUUEFI_RUST_COMPILER="rustc"
export HUUEFI_RUST_FLAGS="-O"
export HUUEFI_GO_COMPILER="go build" # Note: go build is a command, not just compiler
export HUUEFI_ASM_COMPILER="nasm"
export HUUEFI_ASM_FLAGS="-f elf64"

# --- Interpreter settings ---
export HUUEFI_PYTHON_INTERPRETER="python3"
export HUUEFI_NODE_INTERPRETER="node"
export HUUEFI_RUBY_INTERPRETER="ruby"
export HUUEFI_LUA_INTERPRETER="lua5.3" # Explicitly use lua5.3 if installed that way, or just 'lua'

# --- UI settings ---
export HUUEFI_SHOW_BANNER=true      # Display large ASCII art banner on load
export HUUEFI_COLORS=true           # Enable colored output
export HUUEFI_ANIMATIONS=false      # Enable minor console animations (e.g., loading spinners)
export HUUEFI_PROMPT_SYMBOL="🌀"    # Symbol for general HUUEFI messages
export HUUEFI_ERROR_SYMBOL="❌"       # Symbol for error messages
export HUUEFI_SUCCESS_SYMBOL="✅"     # Symbol for success messages
export HUUEFI_WARNING_SYMBOL="⚠️"      # Symbol for warning messages

# --- Performance settings ---
export HUUEFI_CACHE_ENABLED=true    # Enable caching of compiled binaries
export HUUEFI_CACHE_TTL="3600"      # Cache Time-To-Live in seconds (1 hour default)
export HUUEFI_PARALLEL_COMPILE=true # Attempt parallel compilation if applicable
export HUUEFI_MAX_THREADS=4         # Max threads for parallel operations

# --- Security settings (conceptual, requires actual implementation in huuefi-core) ---
export HUUEFI_VALIDATE_INPUT=true   # Validate user input for known vulnerabilities
export HUUEFI_SANDBOX_MODE=false    # Run untrusted code in a sandbox (requires tooling like firejail)
export HUUEFI_MAX_FILE_SIZE="10M"   # Max file size for HUUEFI files to prevent abuse

# --- Auto-cleanup settings ---
export HUUEFI_AUTO_CLEANUP=true     # Automatically clean up temp files and old logs/cache
export HUUEFI_CLEANUP_INTERVAL="7d" # How often to run cleanup (e.g., 1d, 7d, 30d)
export HUUEFI_MAX_LOG_SIZE="10M"    # Max size for log file before rotation/truncation

# --- Notification settings ---
export HUUEFI_NOTIFICATIONS=true    # Enable system notifications (e.g., desktop popups)
export HUUEFI_NOTIFY_ON_SUCCESS=true
export HUUEFI_NOTIFY_ON_ERROR=true

# --- Update settings (conceptual) ---
export HUUEFI_AUTO_UPDATE=false                 # Enable automatic updates for HUUEFI core
export HUUEFI_UPDATE_CHECK_INTERVAL="30d"       # How often to check for updates

# --- Backup settings (specific to file backups when changing modes) ---
export HUUEFI_BACKUP_ENABLED=true               # Create backups of .HUUEFI files before changes
export HUUEFI_BACKUP_COUNT=10                   # Number of backups to retain per file
export HUUEFI_BACKUP_COMPRESSION=false          # Compress backups (requires gzip/tar, not implemented yet)

# --- Network settings (if future features require external access) ---
export HUUEFI_NETWORK_TIMEOUT=30    # Default timeout for network operations
export HUUEFI_DOWNLOAD_RETRIES=3    # How many times to retry a failed download

# --- User customization area ---
# Add your custom settings or override defaults here.
# For more complex customizations, you can use user-config.zsh

# Load user custom config if exists (Optional, for advanced users)
# This file won't be overwritten by updates and can contain custom aliases/functions.
if [[ -f "$HUUEFI_HOME/user-config.zsh" ]]; then
    source "$HUUEFI_HOME/user-config.zsh"
fi
EOF
echo "✅ huuefi.conf created."

# ==================== CREATE MODE TEMPLATES ==================== #
echo "📦 Creating default mode templates..."

# C++ Mode
cat > "$HUUEFI_DIR/modes/cpp.hmode" << 'EOL'
#include <iostream>
#include <vector>
#include <string>

using namespace std;

int main(int argc, char* argv[]) {
    cout << "🚀 HUUEFI C++ режим работает!" << endl;
    cout << "Аргументы: " << argc - 1 << endl;
    
    for (int i = 0; i < argc; i++) {
        cout << "  " << i << ": " << argv[i] << endl;
    }
    
    return 0;
}
EOL

# Python Mode
cat > "$HUUEFI_DIR/modes/python.hmode" << 'EOL'
print("🐍 HUUEFI Python режим работает!")
import sys
print(f"Аргументы: {sys.argv}")

numbers = [1, 2, 3, 4, 5]
squares = [x**2 for x in numbers]
print(f"Квадраты: {squares}")

class HUUEFIProgram:
    def __init__(self, name):
        self.name = name
    
    def run(self):
        print(f"Запущена программа: {self.name}")

program = HUUEFIProgram("Python Demo")
program.run()
EOL

# Rust Mode
cat > "$HUUEFI_DIR/modes/rust.hmode" << 'EOL'
fn main() {
    println!("🦀 HUUEFI Rust режим работает!");
    
    let args: Vec<String> = std::env::args().collect();
    println!("Аргументы: {:?}", args);
    
    let mut counter = 0;
    for i in 0..10 {
        counter += i;
    }
    println!("Результат: {}", counter);
}
EOL

# Go Mode
cat > "$HUUEFI_DIR/modes/go.hmode" << 'EOL'
package main

import (
    "fmt"
    "os"
)

func main() {
    fmt.Println("🐹 HUUEFI Go режим работает!")
    fmt.Println("Аргументы:", os.Args)
    
    ch := make(chan int)
    
    go func() {
        sum := 0
        for i := 1; i <= 10; i++ {
            sum += i
        }
        ch <- sum
    }()
    
    result := <-ch
    fmt.Println("Сумма от 1 до 10:", result)
    
    p := Program{Name: "Go Demo"}
    p.Run()
}

type Program struct {
    Name string
}

func (p *Program) Run() {
    fmt.Printf("Запущена программа: %s\n", p.Name)
}
EOL

# Haskell Mode
cat > "$HUUEFI_DIR/modes/haskell.hmode" << 'EOL'
main :: IO ()
main = do
    putStrLn "λ HUUEFI Haskell режим работает!"
    
    args <- getArgs
    putStrLn $ "Аргументы: " ++ show args
    
    let result = sum [1..10]
    putStrLn $ "Сумма: " ++ show result
    
    let factorial n = product [1..n]
    putStrLn $ "Факториал 5: " ++ show (factorial 5)
EOL

# Node.js Mode
cat > "$HUUEFI_DIR/modes/node.hmode" << 'EOL'
console.log("⬢ HUUEFI Node.js режим работает!");
console.log("Аргументы:", process.argv);

const fs = require('fs').promises;

async function demo() {
    try {
        const files = await fs.readdir('.');
        console.log("Файлы в папке:", files);
    } catch (error) {
        console.error("Ошибка:", error);
    }
}

demo();

const numbers = [1, 2, 3, 4, 5];
const doubled = numbers.map(x => x * 2);
console.log("Удвоенные числа:", doubled);
EOL

# Ruby Mode
cat > "$HUUEFI_DIR/modes/ruby.hmode" << 'EOL'
puts "💎 HUUEFI Ruby режим работает!"
puts "Аргументы: #{ARGV}"

numbers = [1, 2, 3, 4, 5]
squares = numbers.map { |x| x**2 }
puts "Квадраты: #{squares}"

class HUUEFIProgram
  attr_accessor :name
  
  def initialize(name)
    @name = name
  end
  
  def run
    puts "Запущена программа: #{@name}"
  end
end

program = HUUEFIProgram.new("Ruby Demo")
program.run

3.times do |i|
  puts "Итерация #{i + 1}"
end
EOL

# Lua Mode
cat > "$HUUEFI_DIR/modes/lua.hmode" << 'EOL'
print("🌙 HUUEFI Lua режим работает!")
print("Аргументы:")
for i, v in ipairs(arg) do
    print("  " .. i .. ": " .. v)
end

local numbers = {1, 2, 3, 4, 5}
local squares = {}
for i, v in ipairs(numbers) do
    squares[i] = v * v
end

print("Квадраты:")
for i, v in ipairs(squares) do
    print("  " .. i .. ": " .. v)
end

local function greet(name)
    return "Привет, " .. name .. "!"
end

print(greet("Lua программист"))
EOL

# Pure Assembly Mode
cat > "$HUUEFI_DIR/modes/asm.hmode" << 'EOL'
section .data
    msg db '🚀 HUUEFI Pure Assembly режим!', 0xA
    len equ $ - msg

section .text
    global _start

_start:
    ; Вывод сообщения
    mov rax, 1
    mov rdi, 1
    mov rsi, msg
    mov rdx, len
    syscall
    
    ; Завершение
    mov rax, 60
    xor rdi, rdi
    syscall
EOL

# Hybrid Mode (C++ + inline ASM)
cat > "$HUUEFI_DIR/modes/hybrid.hmode" << 'EOL'
#include <iostream>
using namespace std;

// Declare the assembly function
extern "C" void asm_function();

int main() {
    cout << "🎯 HUUEFI Hybrid режим (C++ + Assembly)!" << endl;
    
    // Inline Assembly example (simple instruction)
    asm("mov $1, %rax"); // Move immediate value 1 into rax register
    asm("nop");         // No operation
    
    // Call the external assembly function
    asm_function();
    
    cout << "C++ код продолжает работу после вызова ассемблера." << endl;
    return 0;
}

// Assembly functions can be embedded using raw assembly syntax for the assembler
// .global makes the function visible to the linker
// .type defines symbol type (function) - modern assemblers infer well, but explicit is safer
// For macOS/ARM, syntax may vary (e.g., uses underscores for global symbols: _asm_function)
asm(
".global asm_function\n"
".type asm_function, @function\n"
"asm_function:\n"
"    mov $42, %rax    // Example: move 42 into rax\n"
"    ret              // Return from function\n"
);
EOL

# HUUEFI-LANG Mode (Placeholder for custom language)
cat > "$HUUEFI_DIR/modes/huuefi-lang.hmode" << 'EOL'
// HUUEFI собственный язык программирования
// Синтаксис: C-подобный с русскими ключевыми словами

функция главная() {
    печать("🔥 HUUEFI собственный язык!");
    печать("Аргументы: ", аргументы);
    
    число x = 10;
    текст сообщение = "Привет мир!";
    логический флаг = истина;
    
    если (x > 5) {
        печать("x больше 5");
    } иначе {
        печать("x меньше или равно 5");
    }
    
    для (число i = 0; i < 5; i++) {
        печать("Итерация: ", i);
    }
    
    число результат = сумма(5, 3);
    печать("Сумма: ", результат);
    
    вернуть 0;
}

функция число сумма(число a, число b) {
    вернуть a + b;
}

главная();
EOL

echo "✅ Default mode templates created."

# ==================== INSTALL DEPENDENCIES ==================== #
echo "📦 Installing development dependencies (this may require sudo password)..."

# List of packages to install
declare -a packages=("g++" "nasm" "rustc" "ghc" "python3" "nodejs" "golang" "ruby" "lua5.3")
missing_packages=()

# Check for each package
for pkg in "${packages[@]}"; do
    if ! command -v "$pkg" &> /dev/null; then
        echo "   -> $pkg not found."
        missing_packages+=("$pkg")
    fi
done

if (( ${#missing_packages[@]} > 0 )); then
    echo "Need to install: ${missing_packages[*]}"
    sudo apt update || echo "⚠️ Failed to update apt repositories. Installation might fail."
    sudo apt install -y "${missing_packages[@]}"
    if [[ $? -ne 0 ]]; then
        echo "$HUUEFI_ERROR_SYMBOL Failed to install some dependencies. Please check the output above."
    else
        echo "✅ Dependencies installed."
    fi
else
    echo "✅ All required development tools are already installed."
fi

# ==================== SET PERMISSIONS ==================== #
echo "🔒 Setting file permissions..."
chmod +x "$HUUEFI_DIR/huuefi-core.zsh"
chmod -R 755 "$HUUEFI_DIR" # Set executable for directories and files for user, read for others
echo "✅ Permissions set."

# ==================== ADD TO .ZSHRC ==================== #
echo "✏️ Adding HUUEFI to your Zsh configuration ($ZSHRC_FILE)..."
if ! grep -q "source '$HUUEFI_DIR/huuefi-core.zsh'" "$ZSHRC_FILE"; then
    echo "" >> "$ZSHRC_FILE"
    echo "# === HUUEFI Multi-Language System === #" >> "$ZSHRC_FILE"
    echo "# This line loads the core HUUEFI functions and configuration." >> "$ZSHRC_FILE"
    echo "# Do not remove or modify this line unless you know what you're doing." >> "$ZSHRC_FILE"
    echo "source '$HUUEFI_DIR/huuefi-core.zsh'" >> "$ZSHRC_FILE"
    echo "# ==================================== #" >> "$ZSHRC_FILE"
    echo "✅ Added HUUEFI source line to $ZSHRC_FILE."
else
    echo "✅ HUUEFI source line already present in $ZSHRC_FILE."
fi

echo ""
echo "🎉 HUUEFI Pro Max Ultra Installation Complete!"
echo "------------------------------------------------"
echo "To start using HUUEFI, please restart your terminal or run:"
echo "➡️  source $ZSHRC_FILE"
echo ""
echo "Configuration file: $HUUEFI_DIR/huuefi.conf"
echo "You can edit this file to customize HUUEFI settings."
echo "For help using HUUEFI, type 'huuefi-help-mode' in your terminal."
echo "Enjoy the multi-language powerhouse! 🚀"
echo "------------------------------------------------"