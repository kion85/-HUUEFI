#!/bin/bash

echo "🚀 HUUEFI Pro Max Ultra Installation"
echo "===================================="

# Create directories
HUUEFI_DIR="$HOME/.huuefi"
mkdir -p "$HUUEFI_DIR"/{cache,modes,logs,temp,backups}

# Backup existing .zshrc
if [[ -f ~/.zshrc ]]; then
    BACKUP_FILE="$HUUEFI_DIR/backups/zshrc.backup.$(date +%Y%m%d_%H%M%S)"
    cp ~/.zshrc "$BACKUP_FILE"
    echo "✅ Создана резервная копия .zshrc: $BACKUP_FILE"
fi

# ==================== СОЗДАЕМ ОСНОВНОЙ ФАЙЛ ==================== #
echo "📦 Creating HUUEFI Core System..."

# Создаем huuefi-core.zsh (как в предыдущем скрипте)
cat > "$HUUEFI_DIR/huuefi-core.zsh" << 'EOF'
#!/bin/zsh
# HUUEFI CORE SYSTEM v3.0
# Multi-language execution environment

# ... [остальное содержимое huuefi-core.zsh без изменений]
EOF

# ==================== СОЗДАЕМ КОНФИГ ФАЙЛ ==================== #
echo "📦 Creating huuefi.conf configuration..."

# Создаем huuefi.conf (как в предыдущем скрипте)
cat > "$HUUEFI_DIR/huuefi.conf" << 'EOF'
# ... [содержимое huuefi.conf без изменений]
EOF

# ==================== ОБНОВЛЯЕМ .ZSHRC ==================== #
echo "📝 Updating .zshrc..."

# Сначала создаем временный файл с новым содержимым
TEMP_ZSHRC=$(mktemp)

# Добавляем ваши текущие настройки
cat > "$TEMP_ZSHRC" << 'EOF'
# If you come from bash you might have to change your $PATH.
# export PATH=$HOME/bin:/usr/local/bin:$PATH

export ZSH="$HOME/.oh-my-zsh"

ZSH_THEME="agnosterzak"

plugins=( 
    git
    zsh-autosuggestions
    zsh-syntax-highlighting
)

source $ZSH/oh-my-zsh.sh

# Display Pokemon-colorscripts
# Project page: https://gitlab.com/phoneybadger/pokemon-colorscripts#on-other-distros-and-macos
#pokemon-colorscripts --no-title -s -r #without fastfetch
pokemon-colorscripts --no-title -s -r | fastfetch -c $HOME/.config/fastfetch/config-pokemon.jsonc --logo-type file-raw --logo-height 10 --logo-width 5 --logo -

# fastfetch. Will be disabled if above colorscript was chosen to install
#fastfetch -c $HOME/.config/fastfetch/config-compact.jsonc

# Set-up icons for files/directories in terminal using lsd
alias ls='lsd'
alias l='ls -l'
alias la='ls -a'
alias lla='ls -la'
alias lt='ls --tree'
EOF

# Добавляем хуефи интеграцию
cat >> "$TEMP_ZSHRC" << 'EOF'

# ==================== HUUEFI INTEGRATION ==================== #
export HUUEFI_HOME="$HOME/.huuefi"
source "$HUUEFI_HOME/huuefi-core.zsh"

# Ваши дополнительные алиасы и настройки могут быть здесь
alias hmode='huuefi-mode'
alias hhelp='huuefi-help'
alias hdetect='huuefi-detect-mode'

echo "🌀 HUUEFI PRO extension loaded! Type 'hhelp' for commands"
EOF

# Копируем временный файл в .zshrc
cp "$TEMP_ZSHRC" ~/.zshrc
rm "$TEMP_ZSHRC"

# ==================== УСТАНАВЛИВАЕМ ЗАВИСИМОСТИ ==================== #
echo "📦 Installing dependencies..."
sudo apt update
sudo apt install -y g++ nasm rustc ghc python3 nodejs golang ruby lua5.3

# ==================== НАСТРАИВАЕМ ПРАВА ==================== #
chmod +x "$HUUEFI_DIR/huuefi-core.zsh"
chmod 755 "$HUUEFI_DIR"

echo "✅ Installation complete!"
echo "💻 Restart your terminal or run: source ~/.zshrc"
echo "📋 Configuration file: $HUUEFI_DIR/huuefi.conf"
echo "📁 Backup directory: $HUUEFI_DIR/backups"